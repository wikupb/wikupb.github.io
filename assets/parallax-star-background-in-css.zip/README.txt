A Pen created at CodePen.io. You can find this one at http://codepen.io/saransh/pen/BKJun.

 Using a very simple sass function, and CSS animation keyframes, built parallax scrolling stars in space. The sass function creates a random star field on each load.

SASS function:
https://coderwall.com/p/nqxusa
by Kushagra Gour @chinchang457